import plugins
from sdv_model import Vehicle
vehicle = Vehicle()
