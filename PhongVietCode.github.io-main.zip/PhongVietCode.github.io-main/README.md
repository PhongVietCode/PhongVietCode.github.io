# BetterLuck-Team
1. run sever you need to use this command first to run local sever in file "index.js":
`yarn add express socket.io`
then:
`yarn start`
2. Open our digitalauto project
3. Each browser will create a different car
